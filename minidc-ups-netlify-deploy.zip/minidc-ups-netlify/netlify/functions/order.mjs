export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ ok: false, error: "Method not allowed" }, { status: 405 });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    console.error("Missing Telegram environment variables");
    return Response.json({ ok: false, error: "Сервіс замовлень ще не налаштований." }, { status: 503 });
  }

  let order;
  try {
    order = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Некоректні дані." }, { status: 400 });
  }

  const name = String(order.name || "").trim().slice(0, 80);
  const phone = String(order.phone || "").trim().slice(0, 24);
  const quantity = Number(order.quantity);
  const total = Number(order.total);

  if (name.length < 2 || phone.length < 9 || ![1, 2].includes(quantity) ||
      total !== (quantity === 1 ? 1300 : 2500)) {
    return Response.json({ ok: false, error: "Перевірте ім’я, телефон і кількість товару." }, { status: 400 });
  }

  const escapeHtml = (value) => value.replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);

  const message = [
    "🛒 <b>Нове замовлення — DropShop</b>",
    "",
    `<b>Товар:</b> Mini DC UPS 10 400 мАг`,
    `<b>Кількість:</b> ${quantity} шт.`,
    `<b>Сума:</b> ${total} грн`,
    `<b>Ім’я:</b> ${escapeHtml(name)}`,
    `<b>Телефон:</b> ${escapeHtml(phone)}`
  ].join("\n");

  try {
    const telegramResponse = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "HTML" })
    });
    const telegramResult = await telegramResponse.json();
    if (!telegramResponse.ok || !telegramResult.ok) {
      console.error("Telegram API error", telegramResult);
      return Response.json({ ok: false, error: "Не вдалося надіслати заявку. Спробуйте пізніше." }, { status: 502 });
    }
    return Response.json({ ok: true });
  } catch (error) {
    console.error("Telegram request failed", error);
    return Response.json({ ok: false, error: "Помилка з’єднання. Спробуйте пізніше." }, { status: 502 });
  }
};
